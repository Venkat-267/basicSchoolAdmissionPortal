from tkinter import *
from tkinter import ttk
import mysql.connector as my


class Admin:
    def __init__(self,root):
        self.root=root
        self.root.title("AWIS")
        self.root.geometry("1350x700+0+0")

        title=Label(self.root, text="AWIS STUDENT MANAGEMENT SYSTEM",bd=10,relief=GROOVE, font=("ariel",30,"bold"), bg="black", fg="aquamarine")
        title.pack(side=TOP,fill=X)


        deletebtn=Button(self.root, text="Delete", font=("times new roman",15),width=10,bg="red",fg="black", command=lambda:self.delete_data()).place(x=1150,y=15)

        self.aadhaar_no=0

        scroll_x=Scrollbar(self.root,orient=HORIZONTAL)
        scroll_y = Scrollbar(self.root, orient=VERTICAL)
        self.student_table=ttk.Treeview(self.root,columns=("student name","parent name","contact","email","class","age","dob","single child","aadhaar","pincode","last school","gender"),xscrollcommand=scroll_x.set, yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_y.config(command=self.student_table.yview)
        scroll_x.config(command=self.student_table.xview)

        self.student_table.heading("student name", text="student name")
        self.student_table.heading("parent name", text="parent name")
        self.student_table.heading("contact", text="contact")
        self.student_table.heading("email", text="email")
        self.student_table.heading("class", text="class")
        self.student_table.heading("age", text="age")
        self.student_table.heading("dob", text="dob")
        self.student_table.heading("single child", text="single child")
        self.student_table.heading("aadhaar", text="aadhaar")
        self.student_table.heading("pincode", text="pincode")
        self.student_table.heading("last school", text="last school")
        self.student_table.heading("gender", text="gender")
        self.student_table['show']="headings"

        self.student_table.column("student name",width=100)
        self.student_table.column("parent name",width=100)
        self.student_table.column("contact",width=100)
        self.student_table.column("email",width=150)
        self.student_table.column("class",width=20)
        self.student_table.column("age",width=20)
        self.student_table.column("dob",width=100)
        self.student_table.column("single child",width=50)
        self.student_table.column("aadhaar",width=50)
        self.student_table.column("pincode",width=50)
        self.student_table.column("last school",width=100)
        self.student_table.column("gender",width=50)
        self.student_table.pack(fill=BOTH,expand=1)
        self.student_table.bind("<ButtonRelease-1>",self.get_cursor)
        self.fetch_data()




    def fetch_data(self):
        con = my.connect(host="localhost", user="root", password="tiger", database="schooladmissionportal")
        cur = con.cursor()
        cur.execute("select*from school")
        rows=cur.fetchall()
        if len(rows) !=0:
            self.student_table.delete(*self.student_table.get_children())
            for row in rows:
                self.student_table.insert('',END,values=row)
            con.commit()
        con.close()


    def get_cursor(self,event):
        cursor_row=self.student_table.focus()
        contents=self.student_table.item(cursor_row)
        row=contents['values']
        self.aadhaar_no=(row[8])


    def delete_data(self):
        con = my.connect(host="localhost", user="root", password="tiger", database="schooladmissionportal")
        cur = con.cursor()
        cur.execute("delete from school where aadhaar={}".format(self.aadhaar_no))
        con.commit()
        con.close()
        self.fetch_data()


root=Tk()
obj=Admin(root)
root.mainloop()